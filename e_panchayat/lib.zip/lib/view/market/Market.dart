import 'package:e_panchayat/view/home/home.dart';
import 'package:flutter/material.dart';

// void main() => runApp(MarketRatesApp());

class MarketRatesApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Market Rates',
      theme: ThemeData(
        primarySwatch: Colors.green,
        scaffoldBackgroundColor:
            Color.fromRGBO(229, 230, 248, 1), // Set background color here
      ),
      home: MarketRatesPage(),
    );
  }
}

class MarketRatesPage extends StatefulWidget {
  @override
  _MarketRatesPageState createState() => _MarketRatesPageState();
}

class _MarketRatesPageState extends State<MarketRatesPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  final List<Product> vegetables = [
    Product(
        name: "Tomatoes", rate: "₹40/kg", image: "assets/images/tomatoes.png"),
    Product(name: "Onions", rate: "₹30/kg", image: "assets/images/onions.jpg"),
    Product(
        name: "Potatoes", rate: "₹20/kg", image: "assets/images/potatoes.jpg"),
    Product(
        name: "Carrots", rate: "₹60/kg", image: "assets/images/carrots.jpg"),
    Product(
        name: "Cucumbers",
        rate: "₹50/kg",
        image: "assets/images/cucumbers.jpg"),
    Product(
        name: "Spinach", rate: "₹40/kg", image: "assets/images/spinach.jpg"),
  ];

  final List<Product> fruits = [
    Product(name: "Apples", rate: "₹120/kg", image: "assets/images/apples.jpg"),
    Product(
        name: "Bananas", rate: "₹50/dozen", image: "assets/images/bananas.png"),
    Product(
        name: "Mangoes", rate: "₹150/kg", image: "assets/images/mangoes.jpg"),
    Product(
        name: "Oranges", rate: "₹80/kg", image: "assets/images/oranges.jpg"),
    Product(name: "Grapes", rate: "₹90/kg", image: "assets/images/grapes.jpg"),
    Product(
        name: "Pineapple",
        rate: "₹60/kg",
        image: "assets/images/pineapple.jpg"),
  ];

  final List<Product> grains = [
    Product(name: "Rice", rate: "₹60/kg", image: "assets/images/rice.jpg"),
    Product(name: "Wheat", rate: "₹45/kg", image: "assets/images/wheat.jpg"),
    Product(name: "Barley", rate: "₹70/kg", image: "assets/images/barley.jpg"),
    Product(name: "Oats", rate: "₹80/kg", image: "assets/images/oats.jpg"),
    Product(name: "Maize", rate: "₹50/kg", image: "assets/images/maize.jpg"),
    Product(
        name: "Millets", rate: "₹75/kg", image: "assets/images/millets.jpg"),
  ];

  List<Product> currentProducts = [];
  List<bool> isExpanded = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);

    // Initialize with the first category: Vegetables
    currentProducts = vegetables;
    isExpanded = List<bool>.filled(currentProducts.length, false);

    _tabController.addListener(() {
      setState(() {
        if (_tabController.index == 0) {
          currentProducts = vegetables;
        } else if (_tabController.index == 1) {
          currentProducts = fruits;
        } else {
          currentProducts = grains;
        }
        // Reset expansion state
        isExpanded = List<bool>.filled(currentProducts.length, false);
      });
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(60.0), // Minimized height
        child: AppBar(
          leading: IconButton(
            icon: Icon(Icons.arrow_back), // Back arrow icon
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Home()),
              ); // Go back to the previous screen
            },
          ),
          title: Row(
            children: [
              Image.asset(
                "assets/images/logo.png",
                height: 100,
                width: 50,
              ),
              const SizedBox(
                width: 10,
              ),
              Text(
                'e-Panchayat',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 25),
              ),
            ],
          ),

          centerTitle: true, // Center the title
          flexibleSpace: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color(0xFF090979),
                  Color(0xFF00d4ff), // Green color
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          Text('Current Market Rates', textAlign: TextAlign.center),
          Container(
            color: Color(
                0xFFB1D2F9), // Darker shade of the original background color
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: TabBar(
                controller: _tabController,
                indicatorColor:
                    Colors.white, // White indicator for better contrast
                labelColor: Color(0xFF73EBAA), // Light green label color
                unselectedLabelColor:
                    Colors.grey, // Grey color for unselected tabs
                tabs: [
                  Tab(text: 'Vegetables'),
                  Tab(text: 'Fruits'),
                  Tab(text: 'Grains'),
                ],
              ),
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildProductList(vegetables),
                _buildProductList(fruits),
                _buildProductList(grains),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProductList(List<Product> products) {
    return ListView.builder(
      itemCount: products.length,
      itemBuilder: (context, index) {
        final product = products[index];
        return AnimatedProductCard(
          product: product,
          isExpanded: isExpanded[index],
          onTap: () {
            setState(() {
              isExpanded[index] = !isExpanded[index];
            });
          },
        );
      },
    );
  }
}

class AnimatedProductCard extends StatelessWidget {
  final Product product;
  final bool isExpanded;
  final VoidCallback onTap;

  const AnimatedProductCard({
    required this.product,
    required this.isExpanded,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        margin: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        color: Color(0xFFF9F9F9), // Off-white color for the container
        child: AnimatedContainer(
          duration: Duration(milliseconds: 500),
          curve: Curves.easeInOut,
          height: 100, // Increased height of the container
          child: Row(
            children: [
              AnimatedContainer(
                duration: Duration(milliseconds: 500),
                curve: Curves.easeInOut,
                width: isExpanded
                    ? 120
                    : 70, // Increased width of the image when expanded
                child: Image.asset(product.image, fit: BoxFit.cover),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        product.name,
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      if (isExpanded)
                        Text(
                          product.rate,
                          style:
                              TextStyle(fontSize: 18, color: Colors.grey[700]),
                        ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class Product {
  final String name;
  final String rate;
  final String image;

  Product({required this.name, required this.rate, required this.image});
}
