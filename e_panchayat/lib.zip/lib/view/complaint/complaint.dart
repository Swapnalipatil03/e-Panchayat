import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

// void main() {
//   runApp(MyApp());
// }

// class MyApp extends StatelessWidget {
//   const MyApp({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       home: ComplaintScreen(),
//     );
//   }
// }

class ComplaintScreen extends StatefulWidget {
  const ComplaintScreen({super.key});

  @override
  _ComplaintScreenState createState() => _ComplaintScreenState();
}

class _ComplaintScreenState extends State<ComplaintScreen>
    with TickerProviderStateMixin {
  String? selectedComplaintType; // To hold the selected complaint type
  TextEditingController complaintController =
      TextEditingController(); // Controller for the text input

  // Complaint types list
  final List<Map<String, dynamic>> complaintTypes = [
    {'label': 'Dead Animal', 'icon': Icons.pets},
    {'label': 'Construction Work Quality', 'icon': Icons.construction},
    {'label': 'Cleanliness', 'icon': Icons.cleaning_services},
    {'label': 'Street light', 'icon': Icons.lightbulb},
    {'label': 'Water Supply', 'icon': Icons.water_drop},
    {'label': 'Public Toilet Cleanliness', 'icon': Icons.wc},
  ];

  File? _image; // To store the uploaded image
  bool isAllComplaints = false; // Toggle for complaints view

  // Function to pick an image from the camera
  Future<void> _pickImageFromCamera() async {
    final picker = ImagePicker();
    final pickedFile = await picker.getImage(source: ImageSource.camera);
    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  // Function to pick an image from the gallery
  Future<void> _pickImageFromGallery() async {
    final picker = ImagePicker();
    final pickedFile = await picker.getImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  void _showComplaintTypeBottomSheet({bool showTextArea = false}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          height:
              MediaQuery.of(context).size.height * (showTextArea ? 0.7 : 0.5),
          padding: const EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'File Complaint',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
                const SizedBox(height: 10),
                if (showTextArea && selectedComplaintType != null)
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        'Complaint Type: $selectedComplaintType',
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w500),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: complaintController,
                        decoration: const InputDecoration(
                          labelText: 'Write your complaint here',
                          border: OutlineInputBorder(),
                          hintText: 'Enter your complaint...',
                        ),
                        maxLines: 5,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.camera_alt,
                                color: Colors.black),
                            onPressed: _pickImageFromCamera,
                          ),
                          IconButton(
                            icon: const Icon(Icons.photo_library,
                                color: Colors.black),
                            onPressed: _pickImageFromGallery,
                          ),
                        ],
                      ),
                      const SizedBox(height: 3),
                      if (_image != null)
                        Container(
                          height: 150,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            image: DecorationImage(
                              image: FileImage(_image!),
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      const SizedBox(height: 16),
                      Center(
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          style: ElevatedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(
                                vertical: 14, horizontal: 30),
                            backgroundColor: Color.fromRGBO(38, 166, 154, 1),
                            textStyle: const TextStyle(
                                fontSize: 16, color: Colors.black),
                          ),
                          child: const Text(
                            'Submit',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  )
                else
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Please select a complaint type',
                          style: TextStyle(fontSize: 16)),
                      const SizedBox(height: 16),
                      ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: complaintTypes.length,
                        itemBuilder: (BuildContext context, int index) {
                          var complaint = complaintTypes[index];
                          return ListTile(
                            leading:
                                Icon(complaint['icon'], color: Colors.black54),
                            title: Text(complaint['label']),
                            onTap: () {
                              setState(() {
                                selectedComplaintType = complaint['label'];
                              });
                              Navigator.pop(context);
                              _showComplaintTypeBottomSheet(showTextArea: true);
                            },
                          );
                        },
                      ),
                    ],
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    double screenHeight = MediaQuery.of(context).size.height;
    double screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: Color.fromRGBO(229, 230, 248, 1),
      appBar: AppBar(
        backgroundColor: const Color.fromRGBO(0, 137, 123, 1),
        title: const Text('Complaint App'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Toggle Button for "My Complaints" and "All Complaints"
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 8),
                width: screenWidth *
                    1, // Increase container width to 90% of screen width
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      spreadRadius: 2,
                      blurRadius: 8,
                    ),
                  ],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          isAllComplaints = false;
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            vertical: 12, horizontal: 30),
                        decoration: BoxDecoration(
                          color: isAllComplaints
                              ? Colors.transparent
                              : Color.fromRGBO(0, 137, 123, 1),
                          borderRadius: BorderRadius.circular(8),
                          boxShadow: isAllComplaints
                              ? []
                              : [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.1),
                                    spreadRadius: 2,
                                    blurRadius: 8,
                                  ),
                                ],
                        ),
                        child: Text(
                          'My Complaints',
                          style: TextStyle(
                            color:
                                isAllComplaints ? Colors.black : Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          isAllComplaints = true;
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            vertical: 12, horizontal: 30),
                        decoration: BoxDecoration(
                          color: !isAllComplaints
                              ? Colors.transparent
                              : Color.fromRGBO(0, 137, 123, 1),
                          borderRadius: BorderRadius.circular(8),
                          boxShadow: !isAllComplaints
                              ? []
                              : [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.1),
                                    spreadRadius: 2,
                                    blurRadius: 8,
                                  ),
                                ],
                        ),
                        child: Text(
                          'All Complaints',
                          style: TextStyle(
                            color:
                                !isAllComplaints ? Colors.black : Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 15),
            // Content for My Complaints or All Complaints
            Expanded(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 300),
                child: Container(
                  key: ValueKey<bool>(isAllComplaints),
                  padding: const EdgeInsets.all(16),
                  width: screenWidth *
                      1, // Increase container width to 90% of screen width
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        spreadRadius: 2,
                        blurRadius: 8,
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        isAllComplaints ? 'All Complaints' : 'My Complaints',
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        isAllComplaints
                            ? 'Here is a list of all complaints.'
                            : 'No complaints registered yet.',
                        style: const TextStyle(fontSize: 16),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(height: screenHeight * 0.05),
            // Raise Complaint Button
            Center(
              child: ElevatedButton(
                onPressed: () {
                  _showComplaintTypeBottomSheet();
                },
                style: ElevatedButton.styleFrom(
                  padding:
                      const EdgeInsets.symmetric(vertical: 14, horizontal: 30),
                  backgroundColor: Color.fromRGBO(38, 166, 154, 1),
                  textStyle: const TextStyle(fontSize: 16),
                ),
                child: const Text(
                  'Raise a Complaint',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
