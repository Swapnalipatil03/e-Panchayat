import 'package:e_panchayat/view/login/login.dart';
import 'package:flutter/material.dart';

// void main() {
//   runApp(MyApp());
// }

// class MyApp extends StatelessWidget {
//   const MyApp({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       home: IntroScreen(),
//     );
//   }
// }

class IntroScreen extends StatefulWidget {
  const IntroScreen({super.key});

  @override
  _IntroScreenState createState() => _IntroScreenState();
}

class _IntroScreenState extends State<IntroScreen>
    with SingleTickerProviderStateMixin {
  final PageController _pageController = PageController();
  int currentIndex = 0;

  late AnimationController _animationController;
  late Animation<double> _animation;

  final List<Map<String, String>> features = [
    {
      'title': 'Government Schemes Funds',
      'image': 'assets/images/money-bag.png',
      'description':
          'The Government Schemes Funds section provides detailed information on various government-funded initiatives. Users can view the allocated funds, how they are being utilized, and the transparency of fund distribution across different schemes. This feature ensures accountability by showcasing the amounts spent and remaining funds, helping users understand the efficient use of resources for public welfare.'
    },
    {
      'title': 'Panchayat Details',
      'image': 'assets/images/office-building.png',
      'description':
          'The Panchayat Details section provides comprehensive information about local governance. Users can access key details about the Sarpanch (village head), Gramsevak (village servant), and the village itself. It also includes data about the Panchayats structure, responsibilities, and initiatives aimed at community development, ensuring transparency and easier access to vital local administrative information.'
    },
    {
      'title': 'Labour Stop',
      'image': 'assets/images/builder.png',
      'description':
          'The Labour Stop section connects users with available laborers for various types of work. It allows users to find skilled and unskilled workers in their area, making it easier to hire laborers for construction, agriculture, and other tasks. This feature aims to streamline the process of hiring workers, ensuring efficient labor management and supporting local employment.'
    },
    {
      'title': 'All Schemes',
      'image': 'assets/images/scheme.png',
      'description':
          'The Government Schemes section offers a detailed list of ongoing and past government schemes aimed at welfare and development. Users can access information about various programs, including the eligibility criteria, application process, benefits, and the amount allocated for each scheme. This section helps users stay informed about available opportunities and ensures transparency by providing clear details about the funding, objectives, and impact of each scheme.'
    },
    {
      'title': 'Certificates, Documents',
      'image': 'assets/images/approved.png',
      'description':
          'The Certificates & Documents section enables users to request essential documents like birth and death certificates, as well as other important official records available at the Panchayat. This feature simplifies the process of obtaining legal documents, making it more accessible and efficient for residents to complete official procedures and fulfill personal or legal requirements.'
    },
    {
      'title': 'Meetings',
      'image': 'assets/images/board-meeting.png',
      'description':
          'The Gramsabha Meetings section provides users with details about upcoming and past meetings held by the local Panchayat. It includes information on the agenda, location, date, and time of the meetings, as well as the decisions made during these gatherings. This feature ensures that residents stay informed about community discussions, development plans, and decisions affecting their village, promoting active participation in local governance.'
    },
    {
      'title': 'Complaints',
      'image': 'assets/images/talk.png',
      'description':
          'The Complaints section allows users to easily register and track complaints related to various local issues, such as infrastructure, services, and public grievances. Users can submit their concerns directly to the Panchayat, ensuring that their issues are addressed promptly. This feature promotes transparency, accountability, and effective problem-solving within the community.'
    },
    {
      'title': 'Area & Population',
      'image': 'assets/images/population.png',
      'description':
          'The Area & Population section provides detailed information about the geographical size and population statistics of the village or Panchayat area. It includes data on the total area, population density, demographic distribution, and other relevant statistics that help users understand the communitys growth, resources, and infrastructure needs. This feature aims to promote awareness of local developments and encourage informed decision-making at the community level.'
    },
  ];

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    )..repeat(reverse: true);
    _animation =
        Tween<double>(begin: 0.9, end: 1.1).animate(_animationController);
  }

  @override
  void dispose() {
    _animationController.dispose();
    _pageController.dispose();
    super.dispose();
  }

  void nextPage() {
    if (currentIndex < 3) {
      _pageController.nextPage(
          duration: const Duration(milliseconds: 600), curve: Curves.easeInOut);
    } else {
      // Navigate to main part of the application
    }
  }

  void skip() {
    // Directly navigate to the main part of the app or final screen
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Whole background set to #ECEBFD
          Positioned.fill(
            child: Container(
              color: const Color(
                  0xFFECEBFD), // Background color #ECEBFD (light lavender)
            ),
          ),
          PageView.builder(
            controller: _pageController,
            onPageChanged: (index) {
              setState(() {
                currentIndex = index;
              });
            },
            itemCount: 4,
            itemBuilder: (context, index) {
              return IntroFeaturePage(
                feature1: features[index * 2],
                feature2: features[index * 2 + 1],
                animation: _animation,
              );
            },
          ),
          Positioned(
            bottom: 60,
            left: 20,
            child: TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const Login()),
                );
              },
              child: const Text("Skip",
                  style: TextStyle(fontSize: 16, color: Colors.grey)),
            ),
          ),
          Positioned(
            bottom: 60,
            right: 20,
            child: TextButton(
              onPressed: currentIndex < 3
                  ? nextPage
                  : () {
                      // Navigate to the registration screen or main part of the app
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                const Login()), // Replace with Registration page
                      );
                    },
              child: Text(
                currentIndex < 3 ? "Next" : "Register",
                style: const TextStyle(fontSize: 16, color: Colors.blue),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class IntroFeaturePage extends StatelessWidget {
  final Map<String, String> feature1;
  final Map<String, String> feature2;
  final Animation<double> animation;

  const IntroFeaturePage({
    super.key,
    required this.feature1,
    required this.feature2,
    required this.animation,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          FeatureContainer(feature: feature1, animation: animation),
          const SizedBox(height: 30), // Increased space between the containers
          FeatureContainer(feature: feature2, animation: animation),
        ],
      ),
    );
  }
}

class FeatureContainer extends StatelessWidget {
  final Map<String, String> feature;
  final Animation<double> animation;

  const FeatureContainer(
      {super.key, required this.feature, required this.animation});

  void _showFeatureDetails(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(feature['title'] ?? ''),
          content: Text(feature['description'] ?? 'No description available.'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
              },
              child: const Text('Close'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _showFeatureDetails(context), // Show dialog on tap
      child: Container(
        padding: const EdgeInsets.all(20),
        width: MediaQuery.of(context).size.width * 0.8,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
          boxShadow: const [
            BoxShadow(
              color: Colors.black26,
              blurRadius: 12,
              spreadRadius: 3,
              offset: Offset(3, 6),
            ),
          ],
        ),
        child: Column(
          children: [
            ScaleTransition(
              scale: animation,
              child: Image.asset(
                feature['image'] ?? '',
                width: 80,
                height: 80,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              feature['title'] ?? '',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
