import 'dart:developer';

import 'package:e_panchayat/model/fundingModel.dart';
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../model/funding_pie_chart.dart';
import '../../model/funding_data.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Funding extends StatefulWidget {
  const Funding({super.key});
  @override
  State createState() => _Funding();
}

class _Funding extends State<Funding> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _animation;

  // Track the selected section
  String selectedSection = "Govt. of India";

  // Separate lists for each type of scheme
  List<Fundingmodel> govtIndiaSchemes = [];
  List<Fundingmodel> stateGovtSchemes = [];
  List<Fundingmodel> otherSchemes = [];

  // Loading state
  bool isDataLoading = false;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    );
    _animation = Tween<double>(begin: 0, end: 1).animate(_animationController)
      ..addListener(() {
        setState(() {});
      });
    _animationController.forward();

    // Fetch data on initialization
    getDataFromFirebase();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> getDataFromFirebase() async {
    setState(() {
      isDataLoading = true; // Start loading
    });

    try {
      QuerySnapshot response =
          await FirebaseFirestore.instance.collection("funding_data").get();

      for (var doc in response.docs) {
        var schemes = doc["schemes"] as List<dynamic>;

        for (var scheme in schemes) {
          Fundingmodel fundingModel = Fundingmodel(
            scheme: scheme["scheme"] ?? "N/A", // Provide default value if null
            component: scheme["component"] ?? "N/A",
            expected: scheme["expected"] ?? "N/A",
            reverted: scheme["reverted"] ?? "N/A",
            expenditure: scheme["expenditure"] ?? "N/A",
          );

          String type = (scheme["type"] ?? "other")
              .toString()
              .trim()
              .toLowerCase(); // Handle null and trim whitespace

          // Categorize based on the type field
          if (type == "central") {
            govtIndiaSchemes.add(fundingModel);
          } else if (type == "state") {
            stateGovtSchemes.add(fundingModel);
          } else {
            otherSchemes.add(fundingModel);
          }
        }
      }

      // End loading after successful fetch
      setState(() {
        isDataLoading = false;
      });
    } catch (e) {
      log("Error fetching data: $e");

      setState(() {
        isDataLoading = false; // End loading even on error
      });
    }
  }

  List<Fundingmodel> getListForSelectedSection(String section) {
    switch (section) {
      case "Govt. of India":
        return govtIndiaSchemes;
      case "State Govt.":
        return stateGovtSchemes;
      case "Other":
        return otherSchemes;
      default:
        return [];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(245, 245, 245, 1),
      appBar: AppBar(
        backgroundColor: const Color.fromRGBO(0, 137, 123, 1),
        title: Row(
          children: [
            Image.asset(
              "assets/images/logo.png",
              height: 100,
              width: 50,
            ),
            const SizedBox(
              width: 10,
            ),
            const Text(
              'e-Panchayat',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 25),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications),
            onPressed: () async {
              await getDataFromFirebase();
            },
          ),
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {},
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.only(left: 16.0, right: 16.0, bottom: 16.0),
        children: [
          const SizedBox(height: 5),
          Center(
            child: Column(
              children: [
                const Text(
                  "Funding Distribution",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  height: 200,
                  child: PieChart(
                    PieChartData(
                      sections: FundingPieChart.buildSections(_animation.value),
                      sectionsSpace: 2,
                      centerSpaceRadius: 70,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 30),
          const Text(
            "Scheme-wise Fund Receipt & Expenditure",
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    selectedSection = "Govt. of India";
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: selectedSection == "Govt. of India"
                      ? const Color.fromRGBO(38, 166, 154, 1)
                      : Colors.white,
                ),
                child: Text("Govt. of India",
                    style: TextStyle(
                        color: selectedSection == "Govt. of India"
                            ? Colors.white
                            : Colors.black)),
              ),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    selectedSection = "State Govt.";
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: selectedSection == "State Govt."
                      ? const Color.fromRGBO(38, 166, 154, 1)
                      : Colors.white,
                ),
                child: Text("State Govt.",
                    style: TextStyle(
                        color: selectedSection == "State Govt."
                            ? Colors.white
                            : Colors.black)),
              ),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    selectedSection = "Other";
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: selectedSection == "Other"
                      ? const Color.fromRGBO(38, 166, 154, 1)
                      : Colors.white,
                ),
                child: Text("Other",
                    style: TextStyle(
                        color: selectedSection == "Other"
                            ? Colors.white
                            : Colors.black)),
              ),
            ],
          ),
          const SizedBox(height: 16),
          isDataLoading
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.symmetric(vertical: 16),
                    child: CircularProgressIndicator(),
                  ),
                )
              : ListView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  itemCount: getListForSelectedSection(selectedSection).length,
                  itemBuilder: (context, index) {
                    final funding =
                        getListForSelectedSection(selectedSection)[index];
                    return Card(
                      elevation: 2,
                      margin: const EdgeInsets.symmetric(vertical: 8),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Text(
                              "Scheme: ${funding.scheme}",
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 16),
                            ),
                            const SizedBox(height: 5),
                            Text("Component: ${funding.component}"),
                            Text("Expected: ${funding.expected}"),
                            Text("Reverted: ${funding.reverted}"),
                            Text("Expenditure: ${funding.expenditure}"),
                            const Divider(),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ],
      ),
    );
  }
}
