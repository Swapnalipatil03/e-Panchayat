import 'package:e_panchayat/view/home/home.dart';
import 'package:flutter/material.dart';

class CertificatesPage extends StatelessWidget {
  final List<String> certificates = [
    'Birth Certificate',
    'Death Certificate',
    'Marriage Certificate',
    'Domicile Certificate',
    'Income Certificate',
    'Caste Certificate',
    'Residence Certificate',
    'Character Certificate',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context); // Go back to the previous screen
          },
        ),
        title: Row(
          children: [
            Image.asset(
              "assets/images/logo.png",
              height: 100,
              width: 50,
            ),
            const SizedBox(
              width: 10,
            ),
            Text(
              'e-Panchayat',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 25),
            ),
          ],
        ),
        backgroundColor: const Color.fromRGBO(0, 137, 123, 1),
      ),
      body: Column(
        children: [
          SizedBox(
            height: 20,
          ),
          const Text(
            'Digital Services',
            style: TextStyle(fontSize: 20, color: Colors.black),
          ),
          SizedBox(
            height: 20,
          ),
          Expanded(
            child: ListView.builder(
              itemCount: certificates.length,
              itemBuilder: (context, index) {
                return Card(
                  margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  elevation: 4,
                  child: ListTile(
                    leading: Icon(
                      Icons.document_scanner,
                      color: Color.fromRGBO(38, 166, 154, 1),
                    ),
                    title: Text(
                      certificates[index],
                      style: TextStyle(fontSize: 18),
                    ),
                    trailing: Icon(Icons.arrow_forward, color: Colors.grey),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Color.fromRGBO(38, 166, 154, 1),
                padding: EdgeInsets.symmetric(vertical: 14, horizontal: 24),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              onPressed: () {
                // Add your logic here for requesting a certificate
                showDialog(
                  context: context,
                  builder: (context) {
                    return AlertDialog(
                      title: Text('Request Certificate'),
                      content:
                          Text('Feature to request a certificate coming soon!'),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: Text('OK'),
                        ),
                      ],
                    );
                  },
                );
              },
              child: Text(
                'Request Certificate',
                style: TextStyle(fontSize: 18, color: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
