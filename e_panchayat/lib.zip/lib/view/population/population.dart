import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

// void main() {
//   runApp(const MainApp());
// }

// class MainApp extends StatelessWidget {
//   const MainApp({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return const MaterialApp(
//       home: Population(),
//       debugShowCheckedModeBanner: false,
//     );
//   }
// }

class Population extends StatefulWidget {
  const Population({super.key});
  @override
  State createState() => _Population();
}

class _Population extends State<Population>
    with SingleTickerProviderStateMixin {
  @override
  late AnimationController _animationController;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();

    // Initialize the animation controller
    _animationController = AnimationController(
      vsync: this, // Fixed here
      duration: const Duration(seconds: 2),
    );

    // Define animation to go from 0 to 360 degrees
    _animation = Tween<double>(begin: 0, end: 360).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeOut,
      ),
    );

    // Start the animation
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(229, 230, 248, 1),
      appBar: AppBar(
        backgroundColor: const Color.fromRGBO(0, 137, 123, 1),
        title: Row(
          children: [
            Image.asset(
              "assets/images/logo.png",
              height: 100,
              width: 50,
            ),
            const SizedBox(
              width: 10,
            ),
            Text(
              'e-Panchayat',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 25),
            ),
          ],
        ),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context); // Navigate to the previous screen
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              const Text("Population Dashboard"),
              // Simplified Line Chart for Literacy Rate
              const Text(
                "Literacy Rate (Male, Female, Children)",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(
                height: 200,
                child: LineChart(
                  LineChartData(
                    gridData: FlGridData(show: false), // Hide grid
                    borderData: FlBorderData(
                      show: true,
                      border: const Border(
                        bottom: BorderSide(color: Colors.black, width: 1),
                        left: BorderSide(color: Colors.black, width: 1),
                      ),
                    ),
                    titlesData: const FlTitlesData(
                      show: true,
                      leftTitles: AxisTitles(
                        sideTitles: SideTitles(showTitles: true, interval: 20),
                      ),
                      bottomTitles: AxisTitles(
                        sideTitles: SideTitles(showTitles: true, interval: 1),
                      ),
                      topTitles: AxisTitles(
                        sideTitles: SideTitles(showTitles: false),
                      ),
                      rightTitles: AxisTitles(
                        sideTitles: SideTitles(showTitles: false),
                      ),
                    ),
                    lineBarsData: [
                      LineChartBarData(
                        spots: [FlSpot(1, 60), FlSpot(2, 70), FlSpot(3, 80)],
                        isCurved: true,
                        color: Colors.blue,
                        barWidth: 4,
                        dotData: FlDotData(show: true),
                      ),
                      LineChartBarData(
                        spots: [FlSpot(1, 65), FlSpot(2, 72), FlSpot(3, 85)],
                        isCurved: true,
                        color: Colors.pink,
                        barWidth: 4,
                        dotData: FlDotData(show: true),
                      ),
                      LineChartBarData(
                        spots: [FlSpot(1, 55), FlSpot(2, 68), FlSpot(3, 75)],
                        isCurved: true,
                        color: Colors.green,
                        barWidth: 4,
                        dotData: FlDotData(show: true),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // Pie Chart for Population Distribution
              const Text(
                "Population Distribution",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              Center(
                child: SizedBox(
                  height: 200,
                  child: AnimatedBuilder(
                    animation: _animation,
                    builder: (context, child) {
                      return PieChart(
                        PieChartData(
                          startDegreeOffset: _animation.value,
                          sections: [
                            PieChartSectionData(
                              value: 40,
                              color: Colors.blue,
                              title: 'Male',
                              radius: 50,
                            ),
                            PieChartSectionData(
                              value: 45,
                              color: Colors.pink,
                              title: 'Female',
                              radius: 50,
                            ),
                            PieChartSectionData(
                              value: 15,
                              color: Colors.green,
                              title: 'Children',
                              radius: 50,
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // Cards for Population Counts
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildInfoCard("Males", "10,000", Colors.blue),
                  _buildInfoCard("Females", "9,500", Colors.pink),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildInfoCard("Children (0-12)", "4,500", Colors.green),
                  _buildInfoCard("Newborns", "500", Colors.orange),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoCard(String title, String value, Color color) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      elevation: 4,
      color: color,
      child: Container(
        width: 150,
        height: 100,
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              value,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
