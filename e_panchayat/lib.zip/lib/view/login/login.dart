import 'package:e_panchayat/view/login/registration_page.dart';
import 'package:flutter/material.dart';
import 'package:e_panchayat/view/home/home.dart';

class Login extends StatefulWidget {
  const Login({super.key});
  @override
  State createState() => _Login();
}

class _Login extends State {
  @override
  Widget build(BuildContext context) {
    debugShowCheckedModeBanner:
    false;
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          width: 900,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              //colors: [Color(0xFF003366), Color(0xFF009688)],
              // colors: [
              //   Color.fromRGBO(229, 230, 248, 1),
              //   Color.fromRGBO(128, 122, 194, 1)
              // ],
              colors: [
                Color.fromRGBO(92, 185, 222, 1),
                Color.fromRGBO(115, 235, 170, 1)
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: Column(
            //mainAxisAlignment: MainAxisAlignment.center,
            //crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              ClipPath(
                clipper: UShapeClipper(),
                child: Container(
                  height: 400,
                  width: double.infinity,
                  color: Colors.black,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      const SizedBox(
                        height: 0,
                      ),
                      const Text(
                        "e-Panchayat",
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 40,
                            color: Colors.white),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(bottom: 30),
                        child: Image.asset(
                          "assets/images/logo.png",
                          height: 250,
                          width: 200,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              //const SizedBox(height: 10),

              //const Spacer(),
              // Bottom Logo and Text
              Padding(
                padding: const EdgeInsets.only(right: 20, left: 20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // const Text("Namaste",
                    //     style: TextStyle(
                    //         fontWeight: FontWeight.bold,
                    //         fontSize: 30,
                    //         color: Colors.white)),
                    const Text.rich(
                      TextSpan(
                        children: [
                          TextSpan(
                            text: 'Namaste ',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 30,
                              color: Colors.black,
                            ),
                          ),
                          TextSpan(
                            text: '🙏🏻 ',
                            style: TextStyle(fontSize: 30),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    const Text("Login",
                        style: TextStyle(
                          fontSize: 20,
                          color: Colors.black,
                        )),
                    const SizedBox(
                      height: 20,
                    ),
                    // Mobile Number TextField
                    TextField(
                      decoration: InputDecoration(
                        labelText: 'Enter Registered Mobile No.',
                        labelStyle: const TextStyle(color: Colors.black),
                        prefixIcon: const Icon(Icons.phone_android,
                            color: Colors.black),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Colors.black),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Colors.black),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Colors.black),
                        ),
                        fillColor: Colors.grey[200],
                        filled: true,
                      ),
                      keyboardType: TextInputType.phone,
                    ),
                    const SizedBox(height: 15),

                    // mPIN TextField
                    TextField(
                      obscureText: true,
                      decoration: InputDecoration(
                        labelText: 'Enter mPIN',
                        labelStyle: const TextStyle(color: Colors.black),
                        prefixIcon: const Icon(Icons.lock, color: Colors.black),
                        suffixIcon: const Icon(Icons.visibility_off,
                            color: Colors.black),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Colors.black),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Colors.black),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Colors.black),
                        ),
                        fillColor: Colors.grey[200],
                        filled: true,
                      ),
                      maxLength: 4,
                      keyboardType: TextInputType.number,
                    ),
                    const SizedBox(height: 40),

                    // Login Button
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                          padding: const EdgeInsets.symmetric(vertical: 15),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const Home()),
                          );
                          // Add your login logic here
                        },
                        child: const Text(
                          'Login',
                          style: TextStyle(fontSize: 18, color: Colors.black),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    // Forgot mPIN and Sign Up text
                    // Row(
                    //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    //   children: [
                    //     TextButton(
                    //       onPressed: () {
                    //         // Forgot mPIN logic
                    //       },
                    //       child: const Text(
                    //         'Forgot mPIN?',
                    //         style: TextStyle(color: Colors.white),
                    //       ),
                    //     ),
                    //     TextButton(
                    //       onPressed: () {
                    //         // Sign Up logic
                    //       },
                    //       child: const Text(
                    //         'Citizen Registration/ Sign Up',
                    //         style: TextStyle(color: Colors.white),
                    //       ),
                    //     ),
                    //   ],
                    // ),
                    const SizedBox(
                      height: 40,
                    ),

                    Center(
                      child: Image.asset(
                        "assets/images/emblem.png",
                        height: 80,
                        width: 110,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class UShapeClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final Path path = Path();
    path.lineTo(0, size.height - 100); // Start from the bottom left
    path.quadraticBezierTo(
      size.width / 2, size.height, // Control point
      size.width, size.height - 100, // End point
    );
    path.lineTo(size.width, 0); // Go to the top right
    path.close();
    return path;
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) {
    return false;
  }
}
