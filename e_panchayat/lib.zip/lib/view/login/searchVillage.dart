import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primaryColor: const Color.fromARGB(255, 112, 106, 181), // Button color
        buttonTheme: ButtonThemeData(
          buttonColor: const Color.fromARGB(255, 112, 106, 181),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color.fromRGBO(229, 230, 248, 1), // Background color
          border: OutlineInputBorder(
            borderSide:
                const BorderSide(color: Color.fromARGB(255, 112, 106, 181)),
            borderRadius: BorderRadius.circular(10),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide:
                const BorderSide(color: Color.fromARGB(255, 112, 106, 181)),
            borderRadius: BorderRadius.circular(10),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide:
                const BorderSide(color: Color.fromARGB(255, 112, 106, 181)),
            borderRadius: BorderRadius.circular(10),
          ),
        ),
        textTheme: const TextTheme(
          titleLarge: TextStyle(
              color: Color.fromARGB(255, 112, 106, 181),
              fontSize: 20,
              fontWeight: FontWeight.bold),
          bodyLarge: TextStyle(
              color: Color.fromARGB(255, 112, 106, 181), fontSize: 16),
        ),
        colorScheme: ColorScheme.fromSwatch().copyWith(
          secondary: const Color.fromARGB(255, 112, 106, 181),
          surface: const Color.fromRGBO(229, 230, 248, 1),
        ),
      ),
      home: PanchayatSearchPage(),
    );
  }
}

class PanchayatSearchPage extends StatefulWidget {
  const PanchayatSearchPage({super.key});

  @override
  _PanchayatSearchPageState createState() => _PanchayatSearchPageState();
}

class _PanchayatSearchPageState extends State<PanchayatSearchPage> {
  int _selectedOption = 0;
  String? _selectedYear;
  String? _selectedState;
  String? _selectedCity;
  String? _selectedZillaParishad;
  String? _selectedGramPanchayat;

  List<String> years = List.generate(7, (index) => (2019 + index).toString());
  List<String> states = ["Maharashtra", "Karnataka", "Tamil Nadu"];
  Map<String, List<String>> cities = {
    "Maharashtra": ["Pune", "Nagpur", "Mumbai"],
    "Karnataka": ["Bangalore", "Mysore", "Hubli"],
    "Tamil Nadu": ["Chennai", "Coimbatore", "Madurai"],
  };
  Map<String, List<String>> zillaParishads = {
    "Maharashtra": ["Pune", "Nagpur", "Mumbai"],
    "Karnataka": ["Bangalore", "Mysore", "Hubli"],
    "Tamil Nadu": ["Chennai", "Coimbatore", "Madurai"],
  };
  Map<String, List<String>> gramPanchayats = {
    "Pune": ["Bhor", "Velhe", "Mulshi"],
    "Nagpur": ["Katol", "Kalmeshwar", "Savner"],
    "Mumbai": ["Andheri", "Borivali", "Dadar"],
    "Bangalore": ["Whitefield", "Koramangala", "Indiranagar"],
    "Mysore": ["Nanjangud", "Hunsur", "K R Nagar"],
    "Hubli": ["Old Hubli", "Unkal", "Gokul Road"],
    "Chennai": ["Alandur", "Perungudi", "Sholinganallur"],
    "Coimbatore": ["Annur", "Sulur", "Madukkarai"],
    "Madurai": ["Thirumangalam", "Melur", "Usilampatti"],
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Set Your Panchayat",
          style: Theme.of(context).textTheme.titleLarge,
        ),
        centerTitle: true,
        elevation: 5,
        backgroundColor: const Color.fromARGB(255, 112, 106, 181),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              buildRadioButton("Search by Name", 1),
              const SizedBox(height: 10),
              buildRadioButton("Search by PIN Code", 2),
              const SizedBox(height: 10),
              buildRadioButton("Search by State & District", 3),
              const SizedBox(height: 20),
              if (_selectedOption == 1) searchByNameWidget(),
              if (_selectedOption == 2) searchByPINWidget(),
              if (_selectedOption == 3) searchByStateDistrictWidget(),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildRadioButton(String title, int value) {
    return RadioListTile(
      title: Text(title, style: Theme.of(context).textTheme.bodyLarge),
      value: value,
      groupValue: _selectedOption,
      onChanged: (value) {
        setState(() {
          _selectedOption = value as int;
        });
      },
      activeColor: const Color.fromARGB(255, 112, 106, 181),
    );
  }

  Widget searchByNameWidget() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        buildYearDropdown(),
        const SizedBox(height: 15),
        buildStateDropdown(),
        if (_selectedState != null) buildCityDropdown(),
        const SizedBox(height: 15),
        const TextField(
          decoration: InputDecoration(
              labelText: "Search by Name", prefixIcon: Icon(Icons.search)),
        ),
        const SizedBox(height: 15),
        if (_selectedZillaParishad != null) buildZillaParishadDropdown(),
        if (_selectedGramPanchayat != null) buildGramPanchayatDropdown(),
        const SizedBox(height: 20),
        ElevatedButton(
          onPressed: () {
            // Navigate to main.dart when "Set Panchayat" is clicked
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (context) => MyApp()), // Navigating to main.dart
            );
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color.fromARGB(255, 112, 106, 181),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          child: const Text("Set Panchayat",
              style: TextStyle(fontSize: 16, color: Colors.white)),
        ),
      ],
    );
  }

  Widget searchByPINWidget() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        buildYearDropdown(),
        const SizedBox(height: 15),
        const TextField(
          decoration: InputDecoration(
              labelText: "Enter PIN Code", prefixIcon: Icon(Icons.pin_drop)),
          keyboardType: TextInputType.number,
        ),
        const SizedBox(height: 20),
        ElevatedButton(
          onPressed: () {
            // Navigate to main.dart when "Search" is clicked
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (context) => MyApp()), // Navigating to main.dart
            );
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color.fromARGB(255, 112, 106, 181),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          child: const Text("Search",
              style: TextStyle(fontSize: 16, color: Colors.white)),
        ),
      ],
    );
  }

  Widget searchByStateDistrictWidget() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        buildYearDropdown(),
        const SizedBox(height: 15),
        buildStateDropdown(),
        if (_selectedZillaParishad != null) buildZillaParishadDropdown(),
        if (_selectedGramPanchayat != null) buildGramPanchayatDropdown(),
        const SizedBox(height: 20),
        ElevatedButton(
          onPressed: () {
            // Navigate to main.dart when "Set My Panchayat" is clicked
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (context) => MyApp()), // Navigating to main.dart
            );
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color.fromARGB(255, 112, 106, 181),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          child: const Text("Set My Panchayat",
              style: TextStyle(fontSize: 16, color: Colors.white)),
        ),
      ],
    );
  }

  Widget buildYearDropdown() {
    return DropdownButtonFormField<String>(
      decoration: const InputDecoration(
        labelText: "Select Year",
        prefixIcon: Icon(Icons.calendar_today),
      ),
      value: _selectedYear,
      onChanged: (newValue) {
        setState(() {
          _selectedYear = newValue;
        });
      },
      items: years.map((year) {
        return DropdownMenuItem<String>(
          value: year,
          child: Text(year),
        );
      }).toList(),
    );
  }

  Widget buildStateDropdown() {
    return DropdownButtonFormField<String>(
      decoration: const InputDecoration(
        labelText: "Select State",
        prefixIcon: Icon(Icons.location_on),
      ),
      value: _selectedState,
      onChanged: (newValue) {
        setState(() {
          _selectedState = newValue;
          _selectedCity = null;
          _selectedZillaParishad = null;
          _selectedGramPanchayat = null;
        });
      },
      items: states.map((state) {
        return DropdownMenuItem<String>(
          value: state,
          child: Text(state),
        );
      }).toList(),
    );
  }

  Widget buildCityDropdown() {
    return DropdownButtonFormField<String>(
      decoration: const InputDecoration(
        labelText: "Select City",
        prefixIcon: Icon(Icons.location_city),
      ),
      value: _selectedCity,
      onChanged: (newValue) {
        setState(() {
          _selectedCity = newValue;
          _selectedZillaParishad = null;
          _selectedGramPanchayat = null;
        });
      },
      items: cities[_selectedState ?? '']?.map((city) {
        return DropdownMenuItem<String>(
          value: city,
          child: Text(city),
        );
      }).toList(),
    );
  }

  Widget buildZillaParishadDropdown() {
    return DropdownButtonFormField<String>(
      decoration: const InputDecoration(
        labelText: "Select Zilla Parishad",
        prefixIcon: Icon(Icons.domain),
      ),
      value: _selectedZillaParishad,
      onChanged: (newValue) {
        setState(() {
          _selectedZillaParishad = newValue;
          _selectedGramPanchayat = null;
        });
      },
      items: zillaParishads[_selectedState ?? '']?.map((zilla) {
        return DropdownMenuItem<String>(
          value: zilla,
          child: Text(zilla),
        );
      }).toList(),
    );
  }

  Widget buildGramPanchayatDropdown() {
    return DropdownButtonFormField<String>(
      decoration: const InputDecoration(
        labelText: "Select Gram Panchayat",
        prefixIcon: Icon(Icons.villa),
      ),
      value: _selectedGramPanchayat,
      onChanged: (newValue) {
        setState(() {
          _selectedGramPanchayat = newValue;
        });
      },
      items: gramPanchayats[_selectedCity ?? '']?.map((panchayat) {
        return DropdownMenuItem<String>(
          value: panchayat,
          child: Text(panchayat),
        );
      }).toList(),
    );
  }
}
