import 'package:e_panchayat/view/login/login.dart';
import 'package:flutter/material.dart';

// void main() {
//   runApp(const MyApp());
// }

// class MyApp extends StatelessWidget {
//   const MyApp({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       theme: ThemeData(
//         primarySwatch: Colors.blue,
//         scaffoldBackgroundColor: Colors.white,
//       ),
//       home: const RegistrationPage(),
//     );
//   }
// }

class RegistrationPage extends StatefulWidget {
  const RegistrationPage({super.key});

  @override
  _RegistrationPageState createState() => _RegistrationPageState();
}

class _RegistrationPageState extends State<RegistrationPage> {
  int currentStep = 1;
  String? selectedProfile;
  String? selectedGender;
  final TextEditingController firstNameController = TextEditingController();
  final TextEditingController lastNameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController =
      TextEditingController();
  final TextEditingController dayController = TextEditingController();
  final TextEditingController monthController = TextEditingController();
  final TextEditingController yearController = TextEditingController();

  @override
  void dispose() {
    firstNameController.dispose();
    lastNameController.dispose();
    emailController.dispose();
    phoneController.dispose();
    passwordController.dispose();
    confirmPasswordController.dispose();
    dayController.dispose();
    monthController.dispose();
    yearController.dispose();
    super.dispose();
  }

  void nextStep() {
    setState(() {
      if (currentStep < 4) currentStep++;
    });
  }

  void previousStep() {
    setState(() {
      if (currentStep > 1) currentStep--;
    });
  }

  Widget _buildProfileSelection() {
    final options = [
      'Myself',
      'My Son',
      'My Daughter',
      'My Brother',
      'My Sister',
      'My Friend',
      'My Relative'
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const CircleAvatar(
          radius: 30,
          backgroundColor: Color(0xFFFFF3E0),
          child: Icon(Icons.person_outline, color: Colors.orange, size: 30),
        ),
        const SizedBox(height: 20),
        const Text(
          'This Profile is for',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 20),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: options.map((option) {
            return InkWell(
              onTap: () {
                setState(() {
                  selectedProfile = option;
                  nextStep();
                });
              },
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey.shade300),
                  borderRadius: BorderRadius.circular(25),
                  color: selectedProfile == option
                      ? Colors.blue.withOpacity(0.1)
                      : Colors.white,
                ),
                child: Text(
                  option,
                  style: TextStyle(
                    color:
                        selectedProfile == option ? Colors.blue : Colors.black,
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildGenderSelection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Your Gender',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 20),
        Row(
          children: [
            Expanded(
              child: _buildGenderOption('Male', Icons.male),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _buildGenderOption('Female', Icons.female),
            ),
          ],
        ),
        const SizedBox(height: 20),
        ElevatedButton(
          onPressed: selectedGender != null ? nextStep : null,
          style: ElevatedButton.styleFrom(
            minimumSize: const Size(double.infinity, 50),
            backgroundColor: const Color(0xFF5CB9DE),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(25),
            ), // Updated to blue color
          ),
          child: const Text('Continue'),
        ),
      ],
    );
  }

  Widget _buildGenderOption(String gender, IconData icon) {
    return InkWell(
      onTap: () {
        setState(() {
          selectedGender = gender;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 15),
        decoration: BoxDecoration(
          border: Border.all(
            color:
                selectedGender == gender ? Colors.blue : Colors.grey.shade300,
          ),
          borderRadius: BorderRadius.circular(25),
          color: selectedGender == gender
              ? Colors.blue.withOpacity(0.1)
              : Colors.white,
        ),
        child: Column(
          children: [
            Icon(icon,
                color: selectedGender == gender ? Colors.blue : Colors.grey),
            const SizedBox(height: 5),
            Text(
              gender,
              style: TextStyle(
                color: selectedGender == gender ? Colors.blue : Colors.black,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPersonalInfo() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Your name',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 20),
        TextField(
          controller: firstNameController,
          decoration: InputDecoration(
            labelText: 'First name',
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        ),
        const SizedBox(height: 20),
        TextField(
          controller: lastNameController,
          decoration: InputDecoration(
            labelText: 'Last name',
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        ),
        const SizedBox(height: 20),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: dayController,
                decoration: InputDecoration(
                  labelText: 'DD',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                keyboardType: TextInputType.number,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: monthController,
                decoration: InputDecoration(
                  labelText: 'MM',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                keyboardType: TextInputType.number,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: yearController,
                decoration: InputDecoration(
                  labelText: 'YYYY',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                keyboardType: TextInputType.number,
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        ElevatedButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const Login()),
            );
          },
          style: ElevatedButton.styleFrom(
            minimumSize: const Size(double.infinity, 50),
            backgroundColor: const Color(0xFF5CB9DE),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(25),
            ), // Updated to blue color
          ),
          child: const Text('Continue'),
        ),
      ],
    );
  }

  Widget _buildContactInfo() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Contact Information',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 20),
        TextField(
          controller: emailController,
          decoration: InputDecoration(
            labelText: 'Email ID',
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        ),
        const SizedBox(height: 20),
        TextField(
          controller: phoneController,
          decoration: InputDecoration(
            labelText: 'Phone Number',
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        ),
        const SizedBox(height: 20),
        // Password field
        TextField(
          controller: passwordController,
          obscureText: true,
          decoration: InputDecoration(
            labelText: 'Password',
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        ),
        const SizedBox(height: 20),
        // Confirm Password field
        TextField(
          controller: confirmPasswordController,
          obscureText: true,
          decoration: InputDecoration(
            labelText: 'Confirm Password',
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        ),
        const SizedBox(height: 20),
        ElevatedButton(
          onPressed: () {
            // Submission logic
          },
          style: ElevatedButton.styleFrom(
            minimumSize: const Size(double.infinity, 50),
            backgroundColor: const Color(0xFF5CB9DE),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(25),
            ), // Updated to blue color
          ),
          child: const Text('Continue'),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Registration")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: IndexedStack(
                index: currentStep - 1,
                children: [
                  _buildProfileSelection(),
                  _buildGenderSelection(),
                  _buildPersonalInfo(),
                  _buildContactInfo(),
                ],
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                if (currentStep > 1)
                  TextButton(
                    onPressed: previousStep,
                    child: const Text("Back"),
                  ),
                if (currentStep < 4)
                  TextButton(
                    onPressed: nextStep,
                    child: const Text("Next"),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
