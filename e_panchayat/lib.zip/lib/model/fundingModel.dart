class Fundingmodel {
  String? scheme;
  String? expected;
  String? component;
  String? reverted;
  String? expenditure;

  Fundingmodel(
      {required this.scheme,
      this.expected,
      this.component,
      this.reverted,
      this.expenditure});
}

List<Fundingmodel> fundingScheme = [];
List<Fundingmodel> govtIndiaSchemes = [];
List<Fundingmodel> stateGovtSchemes = [];
List<Fundingmodel> otherSchemes = [];
