final List<Map<String, String>> meetings = [
  {
    "name": "Gram Panchayat: Kaldapalli [120029]",
    "location": "Odisha > Malkangiri > Podia > Kaldapalli",
    "date": "02-11-2024 12:45 PM",
    "venue": "Kaldapalli GP Meeting Hall",
    "chairperson":
        "Name: Sarita Kunjami (Sarpanch)\nPhone: ********92\nEmail: k**********3@gmail.com",
    "agenda": "Detailed agenda of the meeting.",
    "invitees": "List of invitees for the meeting.",
    "assistant": "Details of the meeting assistant.",
    "attendance": "Attendance details for the meeting.",
  },
  {
    "name": "Gram Panchayat: Simlipal [320101]",
    "location": "Odisha > Mayurbhanj > Baripada > Simlipal",
    "date": "10-11-2024 11:00 AM",
    "venue": "Simlipal GP Conference Hall",
    "chairperson":
        "Name: Rajesh Patel (Chairman)\nPhone: ********85\nEmail: r**********5@gmail.com",
    "agenda": "Detailed agenda of the Simlipal meeting.",
    "invitees": "List of invitees for the Simlipal meeting.",
    "assistant": "Details of the Simlipal meeting assistant.",
    "attendance": "Attendance details for the Simlipal meeting.",
  },
];
